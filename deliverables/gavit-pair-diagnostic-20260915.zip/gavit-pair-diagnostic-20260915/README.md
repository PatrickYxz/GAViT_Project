# Swin44 / GAViT44 配对诊断

目的：在同一批验证图片上比较两个现有模型的预测，判断海岸湿地、沙滩/沙丘、自然草地的错误是漏判还是误报，并留下可进一步分析的具体样本。本次只做预测和成败样本展示；区域划分、实际图边、反馈幅度是拿到本次结果后的后续诊断。

## 服务器运行

将本地交付包 `gavit-pair-diagnostic-20260915.zip` 上传到服务器 `/home/featurize/work/`，逐行运行：

```bash
git -C /home/featurize/work/GAViT_Project status --short --branch
unzip -n /home/featurize/work/gavit-pair-diagnostic-20260915.zip -d /home/featurize/work/
bash /home/featurize/work/gavit-pair-diagnostic-20260915/jobs/run_bigearth_pair_seed44.sh
```

工具在项目目录外运行，读取服务器现有项目代码。无须为这次诊断提交或拉取代码，也不会写入权重或修改split。输入已经按本任务路径配置：

- 项目：`/home/featurize/work/GAViT_Project`
- 划分：项目中的 `bigearth_files/splits/{train,val,test}.csv`
- Swin：`/home/featurize/work/swin44_3080_20260910/swin.pth`
- GAViT：`/home/featurize/work/gavit44_3080_20260909/gavit.pth`
- 两个权重旁边的 `.meta.json` 用于恢复各自架构。

启动后会打印PID、独立输出目录，以及已经填好路径的 `tail -f` / `cat` 命令，直接复制它打印的命令。只看到PID还不代表模型运行正常；日志应依次出现设备信息、两个模型加载记录、`Smoke: 8/8`、`SMOKE PASS`和后续进度。退出日志查看可按Ctrl+C，后台任务继续运行。

## 脚本执行顺序

1. 读取原train/val/test CSV，验证19维二值标签及数量237871/122342/119825，统计类别正例数和三类共现。不加载训练或测试图片。
2. 从val固定抽4096张，抽样seed42。三类中每个正/负标签若不足64个，按标签补充样本；不足64时最多取现有样本。补充组单独标记，绝不合入随机子集的AP/PR。保存行号、路径、完整标签及清单。
3. 检查所选图片文件，读取现有metadata并严格加载权重，记录当前代码/权重摘要；使用原有RGB读取、224预处理及0.5分类阈值。
4. 同一批8张依次送入两个模型，检查输出形状与有限值；通过后自动继续完整清单。默认batch32、workers2、pin_memory=False，不开启AMP，不进行梯度更新。输出的吞吐和显存属于两个模型的配对诊断，不作为正式效率对比。
5. 对随机验证子集计算逐类AP、precision、recall、F1和TP/FP/FN/TN，AP同时与服务器sklearn实现比对。无正例或无负例时AP为N/A；分类指标分母为0时按0记录，解读时查看支持数。
6. 三类分别保留双方各自正确、共同正确、共同错误，并按真实正/负标签分组，每组最多2张，最多48个案例。每组按固定哈希排序选样，不按最大分差挑图；空组明确记录0。

## 看什么结果

日志最终应有 `DIAGNOSTIC COMPLETE`，输出目录中的 `diagnostic.exit` 应为 `diagnostic_exit=0`。

| 产物（输出目录/diagnosis/） | 用途 |
|---|---|
| `report.md` | 先看三类的支持数及两模型AP差值 |
| `per_class.csv` | 完整19类指标；TP/FP/FN/TN区分漏判和误报 |
| `cases.html` + `images/` | 下载整个结果包后，用浏览器打开成败样本页 |
| `cases.csv`、`case_counts.csv` | 案例索引、全部真实标签、每组可用与选中数量 |
| `predictions.csv` | 每张图的19维真实标签与两个模型的预测分数 |
| `pr_curves.csv` | 随机子集PR数据，threshold降序；不用于事后调整正式测试阈值 |
| `manifest.json/csv` | 固定样本清单，源CSV数据行从0计数 |
| `label_support.csv`、`label_statistics.json` | 三个原始split的正例数及目标类共现 |
| `swin_scores.json`、`gavit_scores.json` | 可供本地再次分析的原始预测缓存 |
| `preflight.json`、`loaded_models.json`、`run.json` | 执行配置、来源、真实设备、完成状态与资源 |
| `results.zip` | 上述诊断结果的打包文件，不含模型权重 |

**运行完回传 `results.zip` 即可继续分析。** 如果运行失败，先回传 `diagnostic.log` 末尾及 `diagnostic.exit`；Python捕获的异常还会保存为 `diagnosis/failure.json`。不要把 `prepared_only` 或 `smoke_passed_only` 当作全部诊断完成。进程被SIGKILL或实例消失时可能无法写退出标记。

这些是验证子集诊断结果，不替代既有完整测试集分数。病例关联也不能单独证明图模块造成了错误。

## 本地验证与可选模式

本地无PyTorch/NumPy运行环境；数据抽样、指标、输出、HTML转义和失败退出路径使用标准库测试。真实权重前向、图片解码和GPU资源仍需服务器内置的8张检查。完整运行会额外核对AP与sklearn结果。

```bash
python3 -m unittest tests.test_bigearth_pair_diagnostic -v
python3 tools/diagnose_bigearth_pair.py --help
bash -n jobs/run_bigearth_pair_seed44.sh
```

Python入口支持 `--prepare-only`（只生成标签统计及清单）和 `--smoke-only`（只运行8张）；两者都需要独立的新 `--out`。日常运行直接用上面的启动器即可。新输出统一使用 `pair44_diagnostic_XXXXXX`，失败后保留原目录，再次运行启动器会生成新目录。
